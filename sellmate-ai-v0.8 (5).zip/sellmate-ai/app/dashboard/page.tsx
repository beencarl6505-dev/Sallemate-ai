 "use client";

import { useEffect, useState } from "react";
import {
  Bot, ChevronRight, CircleHelp, LayoutDashboard, MessageCircle,
  Package, Plus, Settings, ShoppingCart, Trash2, Users, Pencil
} from "lucide-react";
import { createClient } from "../../lib/supabase-browser";
import ConversationInbox from "./components/ConversationInbox";

type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  active: boolean;
};

type FAQ = {
  id: string;
  question: string;
  answer: string;
};

const demoChats = [
  { name: "John Kamau", text: "Do you have black Air Max size 42?", time: "2 min" },
  { name: "Mary Wanjiku", text: "How much is delivery to Westlands?", time: "8 min" },
  { name: "Brian Otieno", text: "I want to order two pairs.", time: "14 min" }
];

export default function Dashboard() {
  const supabase = createClient();
  const [active, setActive] = useState("Overview");
  const [businessId, setBusinessId] = useState("");
  const [businessName, setBusinessName] = useState("Your Business");
  const [products, setProducts] = useState<Product[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [loading, setLoading] = useState(true);
  const [productModal, setProductModal] = useState(false);
  const [faqModal, setFaqModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editingFAQ, setEditingFAQ] = useState<FAQ | null>(null);

  async function loadData() {
    setLoading(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { window.location.href = "/login"; return; }

    const { data: business } = await supabase
      .from("businesses").select("id,name").eq("owner_id", user.id).maybeSingle();

    if (!business) { window.location.href = "/onboarding"; return; }

    setBusinessId(business.id);
    setBusinessName(business.name);

    const [{ data: p }, { data: f }] = await Promise.all([
      supabase.from("products").select("*").eq("business_id", business.id).order("created_at", { ascending: false }),
      supabase.from("faqs").select("*").eq("business_id", business.id).order("created_at", { ascending: false })
    ]);

    setProducts((p || []) as Product[]);
    setFaqs((f || []) as FAQ[]);
    setLoading(false);
  }

  useEffect(() => { loadData(); }, []);

  async function deleteProduct(id: string) {
    if (!confirm("Delete this product?")) return;
    await supabase.from("products").delete().eq("id", id);
    await loadData();
  }

  async function toggleProduct(product: Product) {
    await supabase.from("products").update({ active: !product.active }).eq("id", product.id);
    await loadData();
  }

  async function deleteFAQ(id: string) {
    if (!confirm("Delete this FAQ?")) return;
    await supabase.from("faqs").delete().eq("id", id);
    await loadData();
  }

  const nav = [
    ["Overview", LayoutDashboard],
    ["Conversations", MessageCircle],
    ["Products", Package],
    ["Customers", Users],
    ["Orders", ShoppingCart],
    ["AI Settings", Bot],
    ["Business Settings", Settings]
  ] as const;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><Bot size={22} /> SellMate AI</div>
        <div className="business-chip">
          <div className="avatar">{businessName.slice(0,2).toUpperCase()}</div>
          <div><strong>{businessName}</strong><small>Starter plan</small></div>
        </div>
        <nav className="side-nav">
          {nav.map(([label, Icon]) => (
            <button key={label} className={active === label ? "nav-item active" : "nav-item"} onClick={() => setActive(label)}>
              <Icon size={18} /> {label}
            </button>
          ))}
        </nav>
        <div className="side-bottom"><button className="nav-item"><CircleHelp size={18}/> Help</button></div>
      </aside>

      <main className="dashboard">
        <header className="topbar">
          <div><p className="eyebrow">SellMate AI</p><h1>{active}</h1></div>
          <div className="status"><span className="dot"/> AI assistant online</div>
        </header>

        {loading ? <section className="panel placeholder"><h2>Loading your business...</h2></section> :
          active === "Overview" ? (
            <>
              <section className="stats">
                <Stat title="Products" value={String(products.length)} change="Your catalog" />
                <Stat title="Active products" value={String(products.filter(p => p.active).length)} change="Available to AI" />
                <Stat title="FAQs" value={String(faqs.length)} change="AI knowledge" />
                <Stat title="AI status" value="Ready" change="Business data connected" />
              </section>
              <section className="grid-2">
                <div className="panel">
                  <div className="panel-head">
                    <div><h2>Recent conversations</h2><p>WhatsApp conversations will appear here after integration.</p></div>
                    <button className="text-button" onClick={() => setActive("Conversations")}>Open <ChevronRight size={15}/></button>
                  </div>
                  <div className="chat-list">
                    {demoChats.map(c => <div className="chat-row" key={c.name}><div className="avatar">{c.name.split(" ").map(x=>x[0]).join("")}</div><div className="chat-copy"><strong>{c.name}</strong><span>{c.text}</span></div><small>{c.time}</small></div>)}
                  </div>
                </div>
                <div className="panel">
                  <div className="panel-head">
                    <div><h2>Your products</h2><p>Products the AI can recommend.</p></div>
                    <button className="icon-button" onClick={() => {setEditingProduct(null); setProductModal(true)}}><Plus size={18}/></button>
                  </div>
                  <ProductList products={products.slice(0,4)} onEdit={p => {setEditingProduct(p); setProductModal(true)}} onDelete={deleteProduct} onToggle={toggleProduct}/>
                </div>
              </section>
            </>
          ) :
          active === "Products" ? (
            <section className="panel">
              <div className="panel-head">
                <div><h2>Product catalog</h2><p>Everything your AI is allowed to sell and recommend.</p></div>
                <button className="button primary" onClick={() => {setEditingProduct(null); setProductModal(true)}}><Plus size={17}/> Add product</button>
              </div>
              <ProductList products={products} onEdit={p => {setEditingProduct(p); setProductModal(true)}} onDelete={deleteProduct} onToggle={toggleProduct} full/>
            </section>
          ) :
          active === "AI Settings" ? (
            <AIPlayground />
          ) :
          active === "Business Settings" ? (
            <BusinessSettings businessId={businessId} />
          ) :
          active === "Conversations" ? (
            <ConversationInbox />
          ) :
          active === "Customers" ? (
            <section className="panel placeholder"><div className="setup-icon"><Users/></div><h2>Customers</h2><p>Customer records will be created automatically from incoming conversations.</p></section>
          ) :
          <section className="panel placeholder"><div className="setup-icon"><ShoppingCart/></div><h2>Orders</h2><p>Order creation and tracking comes after the conversation system.</p></section>
        }

        {active === "AI Settings" && (
          <section className="panel faq-panel">
            <div className="panel-head">
              <div><h2>Frequently asked questions</h2><p>Answers the AI can use when customers ask common questions.</p></div>
              <button className="button secondary" onClick={() => {setEditingFAQ(null); setFaqModal(true)}}><Plus size={16}/> Add FAQ</button>
            </div>
            <div className="faq-list">
              {faqs.length === 0 && <p>No FAQs yet. Add your first one.</p>}
              {faqs.map(f => <div className="faq-row" key={f.id}><div><strong>{f.question}</strong><span>{f.answer}</span></div><div className="row-actions"><button className="icon-button" onClick={() => {setEditingFAQ(f); setFaqModal(true)}}><Pencil size={15}/></button><button className="icon-button" onClick={() => deleteFAQ(f.id)}><Trash2 size={15}/></button></div></div>)}
            </div>
          </section>
        )}
      </main>

      {productModal && <ProductModal businessId={businessId} product={editingProduct} onClose={() => setProductModal(false)} onSaved={loadData}/>}
      {faqModal && <FAQModal businessId={businessId} faq={editingFAQ} onClose={() => setFaqModal(false)} onSaved={loadData}/>}
    </div>
  );
}

function ProductList({products,onEdit,onDelete,onToggle,full=false}:{products:Product[],onEdit:(p:Product)=>void,onDelete:(id:string)=>void,onToggle:(p:Product)=>void,full?:boolean}) {
  return <div className={full ? "product-list product-list-full" : "product-list"}>
    {products.length === 0 && <p>No products yet. Add your first product.</p>}
    {products.map(p => <div className="product-row" key={p.id}>
      <div className="product-icon"><Package size={17}/></div>
      <div><strong>{p.name}</strong><span>{p.price} · {p.stock} in stock · {p.active ? "Active" : "Inactive"}</span></div>
      <div className="row-actions">
        <button className="toggle" onClick={() => onToggle(p)}>{p.active ? "Disable" : "Enable"}</button>
        <button className="icon-button" onClick={() => onEdit(p)}><Pencil size={15}/></button>
        <button className="icon-button" onClick={() => onDelete(p.id)}><Trash2 size={15}/></button>
      </div>
    </div>)}
  </div>
}

function ProductModal({businessId,product,onClose,onSaved}:{businessId:string,product:Product|null,onClose:()=>void,onSaved:()=>void}) {
  const supabase = createClient();
  const [name,setName]=useState(product?.name||"");
  const [description,setDescription]=useState(product?.description||"");
  const [price,setPrice]=useState(String(product?.price??""));
  const [stock,setStock]=useState(String(product?.stock??0));
  const [saving,setSaving]=useState(false);
  async function save(){
    if(!name.trim() || price==="") return;
    setSaving(true);
    const payload={name:name.trim(),description,price:Number(price),stock:Number(stock)||0};
    if(product) await supabase.from("products").update(payload).eq("id",product.id);
    else await supabase.from("products").insert({...payload,business_id:businessId});
    setSaving(false); onClose(); await onSaved();
  }
  return <div className="modal-backdrop"><div className="modal">
    <h2>{product?"Edit product":"Add product"}</h2>
    <label>Product name</label><input value={name} onChange={e=>setName(e.target.value)} placeholder="Nike Air Max"/>
    <label>Description</label><textarea className="modal-textarea" value={description} onChange={e=>setDescription(e.target.value)} placeholder="Black running shoe..."/>
    <label>Price (KES)</label><input type="number" value={price} onChange={e=>setPrice(e.target.value)} placeholder="12000"/>
    <label>Stock</label><input type="number" value={stock} onChange={e=>setStock(e.target.value)} placeholder="10"/>
    <div className="modal-actions"><button className="button secondary" onClick={onClose}>Cancel</button><button className="button primary" onClick={save}>{saving?"Saving...":"Save product"}</button></div>
  </div></div>
}

function FAQModal({businessId,faq,onClose,onSaved}:{businessId:string,faq:FAQ|null,onClose:()=>void,onSaved:()=>void}) {
  const supabase=createClient(); const [q,setQ]=useState(faq?.question||""); const [a,setA]=useState(faq?.answer||""); const [saving,setSaving]=useState(false);
  async function save(){ if(!q.trim()||!a.trim())return; setSaving(true); if(faq) await supabase.from("faqs").update({question:q.trim(),answer:a.trim()}).eq("id",faq.id); else await supabase.from("faqs").insert({business_id:businessId,question:q.trim(),answer:a.trim()}); setSaving(false); onClose(); await onSaved(); }
  return <div className="modal-backdrop"><div className="modal">
    <h2>{faq?"Edit FAQ":"Add FAQ"}</h2><label>Question</label><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Do you deliver?"/>
    <label>Answer</label><textarea className="modal-textarea" value={a} onChange={e=>setA(e.target.value)} placeholder="Yes, we deliver within Nairobi..."/>
    <div className="modal-actions"><button className="button secondary" onClick={onClose}>Cancel</button><button className="button primary" onClick={save}>{saving?"Saving...":"Save FAQ"}</button></div>
  </div></div>
}

function AIPlayground() {
  const [message,setMessage]=useState(""); const [reply,setReply]=useState(""); const [loading,setLoading]=useState(false);
  async function test(){if(!message.trim())return;setLoading(true);setReply("");try{const r=await fetch("/api/ai",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message})});const d=await r.json();setReply(d.reply||d.error||"No response.");}catch{setReply("Could not connect to AI.")}finally{setLoading(false)}}
  return <section className="panel ai-playground"><div className="setup-icon"><Bot size={25}/></div><h2>Test your AI sales assistant</h2><p>The assistant now uses your real business profile, active products and FAQs.</p><textarea value={message} onChange={e=>setMessage(e.target.value)} placeholder="Example: Do you have black Nike Air Max size 42?"/><button className="button primary" onClick={test} disabled={loading}>{loading?"Thinking...":"Ask AI"}</button>{reply&&<div className="ai-reply"><strong>SellMate AI</strong><p>{reply}</p></div>}</section>
}

function BusinessSettings({businessId}:{businessId:string}) {
  const supabase=createClient(); const [name,setName]=useState(""); const [description,setDescription]=useState(""); const [phone,setPhone]=useState(""); const [saved,setSaved]=useState(false);
  useEffect(()=>{supabase.from("businesses").select("name,description,phone").eq("id",businessId).single().then(({data})=>{if(data){setName(data.name);setDescription(data.description||"");setPhone(data.phone||"")}})},[businessId]);
  async function save(){await supabase.from("businesses").update({name,description,phone}).eq("id",businessId);setSaved(true);setTimeout(()=>setSaved(false),2000)}
  return <section className="panel settings-panel"><h2>Business information</h2><p>Information the AI can use when representing your business.</p><label>Business name</label><input value={name} onChange={e=>setName(e.target.value)}/><label>Description</label><textarea className="modal-textarea" value={description} onChange={e=>setDescription(e.target.value)}/><label>Phone</label><input value={phone} onChange={e=>setPhone(e.target.value)}/><button className="button primary" onClick={save}>{saved?"Saved":"Save changes"}</button></section>
}

function Stat({title,value,change}:{title:string,value:string,change:string}){return <div className="stat-card"><span>{title}</span><strong>{value}</strong><small>{change}</small></div>}
