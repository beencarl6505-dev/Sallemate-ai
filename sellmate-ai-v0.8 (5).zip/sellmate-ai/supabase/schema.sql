-- SellMate AI database schema
-- Run this in Supabase SQL Editor.

create extension if not exists "pgcrypto";

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  description text default '',
  phone text default '',
  currency text not null default 'KES',
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  description text default '',
  price numeric(12,2) not null default 0,
  stock integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.faqs (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  question text not null,
  answer text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text default '',
  phone text default '',
  notes text default '',
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  channel text not null default 'whatsapp',
  status text not null default 'open',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  role text not null check (role in ('customer','assistant','human')),
  content text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  customer_id uuid references public.customers(id) on delete set null,
  status text not null default 'new',
  total numeric(12,2) not null default 0,
  notes text default '',
  created_at timestamptz not null default now()
);

alter table public.businesses enable row level security;
alter table public.products enable row level security;
alter table public.faqs enable row level security;
alter table public.customers enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.orders enable row level security;

create policy "owners can manage businesses"
on public.businesses for all
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

create policy "owners can manage products"
on public.products for all
using (business_id in (select id from public.businesses where owner_id = auth.uid()))
with check (business_id in (select id from public.businesses where owner_id = auth.uid()));

create policy "owners can manage faqs"
on public.faqs for all
using (business_id in (select id from public.businesses where owner_id = auth.uid()))
with check (business_id in (select id from public.businesses where owner_id = auth.uid()));

create policy "owners can manage customers"
on public.customers for all
using (business_id in (select id from public.businesses where owner_id = auth.uid()))
with check (business_id in (select id from public.businesses where owner_id = auth.uid()));

create policy "owners can manage conversations"
on public.conversations for all
using (business_id in (select id from public.businesses where owner_id = auth.uid()))
with check (business_id in (select id from public.businesses where owner_id = auth.uid()));

create policy "owners can manage messages"
on public.messages for all
using (conversation_id in (
  select c.id from public.conversations c
  join public.businesses b on b.id = c.business_id
  where b.owner_id = auth.uid()
))
with check (conversation_id in (
  select c.id from public.conversations c
  join public.businesses b on b.id = c.business_id
  where b.owner_id = auth.uid()
));

create policy "owners can manage orders"
on public.orders for all
using (business_id in (select id from public.businesses where owner_id = auth.uid()))
with check (business_id in (select id from public.businesses where owner_id = auth.uid()));

create index if not exists products_business_id_idx on public.products(business_id);
create index if not exists customers_business_id_idx on public.customers(business_id);
create index if not exists conversations_business_id_idx on public.conversations(business_id);
create index if not exists messages_conversation_id_idx on public.messages(conversation_id);
create index if not exists orders_business_id_idx on public.orders(business_id);
