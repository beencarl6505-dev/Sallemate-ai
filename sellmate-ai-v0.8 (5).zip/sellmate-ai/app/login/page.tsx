 "use client";

import { FormEvent, useState } from "react";
import { Bot } from "lucide-react";
import { createClient } from "../../lib/supabase-browser";

export default function Login() {
  const supabase = createClient();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  async function submit(e: FormEvent) {
    e.preventDefault();
    setMessage("Working...");

    if (mode === "login") {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) return setMessage(error.message);
      window.location.href = "/dashboard";
    } else {
      const { error } = await supabase.auth.signUp({ email, password });
      if (error) return setMessage(error.message);
      setMessage("Account created. Check your email if confirmation is enabled.");
    }
  }

  return (
    <main className="auth-page">
      <form className="auth-card" onSubmit={submit}>
        <div className="brand"><Bot size={22}/> SellMate AI</div>
        <h1>{mode === "login" ? "Welcome back" : "Create your account"}</h1>
        <p>Run your AI sales assistant from one simple dashboard.</p>

        <label>Email</label>
        <input value={email} onChange={e => setEmail(e.target.value)} type="email" required placeholder="you@example.com" />
        <label>Password</label>
        <input value={password} onChange={e => setPassword(e.target.value)} type="password" required minLength={6} placeholder="At least 6 characters" />

        <button className="button primary" type="submit">
          {mode === "login" ? "Log in" : "Create account"}
        </button>

        {message && <div className="auth-message">{message}</div>}

        <button type="button" className="switch" onClick={() => {setMode(mode === "login" ? "signup" : "login"); setMessage("");}}>
          {mode === "login" ? "Need an account? Sign up" : "Already have an account? Log in"}
        </button>
      </form>
    </main>
  );
}
