 "use client";

import { useState } from "react";

export default function WhatsAppSettings() {
  const [phoneNumberId, setPhoneNumberId] = useState("");
  const [token, setToken] = useState("");
  const [saved, setSaved] = useState(false);

  async function save() {
    const res = await fetch("/api/whatsapp/settings", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ phoneNumberId, token })
    });
    setSaved(res.ok);
  }

  return <div className="panel">
    <h2>WhatsApp</h2>
    <p className="muted">Connect your WhatsApp Business number after creating a Meta WhatsApp Business app.</p>
    <div className="form-grid">
      <label>Phone Number ID<input value={phoneNumberId} onChange={e=>setPhoneNumberId(e.target.value)} placeholder="Meta Phone Number ID"/></label>
      <label>Access Token<input type="password" value={token} onChange={e=>setToken(e.target.value)} placeholder="Meta access token"/></label>
    </div>
    <button className="button primary" onClick={save}>Save WhatsApp settings</button>
    {saved && <p className="success-text">Saved. Webhook: /api/webhook/whatsapp</p>}
  </div>
}
