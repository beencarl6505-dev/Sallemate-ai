 "use client";

import { FormEvent, useState } from "react";
import { Bot } from "lucide-react";

export default function Onboarding() {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [phone, setPhone] = useState("");
  const [message, setMessage] = useState("");

  async function submit(e: FormEvent) {
    e.preventDefault();
    setMessage("Creating your business...");
    const res = await fetch("/api/onboarding", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, description, phone, currency: "KES" })
    });
    const data = await res.json();
    if (!res.ok) return setMessage(data.error || "Something went wrong.");
    window.location.href = "/dashboard";
  }

  return (
    <main className="auth-page">
      <form className="auth-card" onSubmit={submit}>
        <div className="brand"><Bot size={22}/> SellMate AI</div>
        <h1>Set up your business</h1>
        <p>This information helps your AI assistant represent your business accurately.</p>

        <label>Business name</label>
        <input value={name} onChange={e => setName(e.target.value)} required placeholder="ABC Sneakers" />

        <label>What does your business sell?</label>
        <textarea className="onboard-textarea" value={description} onChange={e => setDescription(e.target.value)} placeholder="We sell sneakers and casual shoes in Nairobi." />

        <label>Business phone</label>
        <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="+254..." />

        <button className="button primary" type="submit">Continue</button>
        {message && <div className="auth-message">{message}</div>}
      </form>
    </main>
  );
}
