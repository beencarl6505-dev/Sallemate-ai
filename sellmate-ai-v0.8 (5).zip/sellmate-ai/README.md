# SellMate AI v0.6

## Added
- Persistent conversation API.
- Automatic customer creation/update.
- Customer + conversation + message records in Supabase.
- Conversation history passed to the AI.
- Conversation inbox in the dashboard.
- Test customer name/phone fields.
- AI responses are saved to the conversation.

## Test flow
1. Log in.
2. Complete onboarding.
3. Add products and FAQs.
4. Go to **Conversations**.
5. Enter a customer name and optional phone.
6. Send a message.
7. SellMate creates the customer, conversation and messages, then returns the AI reply.
8. Refreshing the page keeps the conversation.

## Next
WhatsApp Business integration is now the major integration milestone. After that we will add lead/order extraction and billing.


## WhatsApp launch configuration

1. Create/configure a Meta WhatsApp Business app and obtain the phone number ID and access token.
2. Deploy this app to a public HTTPS URL.
3. Set `SUPABASE_SERVICE_ROLE_KEY` and a private `WHATSAPP_VERIFY_TOKEN`.
4. In Meta, configure the webhook URL:
   `https://YOUR-DOMAIN.com/api/webhook/whatsapp`
5. Use the same verify token in Meta and `WHATSAPP_VERIFY_TOKEN`.
6. Subscribe the webhook to WhatsApp message events.
7. In SellMate dashboard, save the Meta Phone Number ID and access token.
8. Send a test WhatsApp message to the connected business number.

Important: the webhook route uses the Supabase service role only on the server. Never expose that key in browser code. For a production launch, encrypt provider access tokens and add webhook signature validation/rate limiting.


## Production environment variables

Use the modern Supabase publishable key:
`NEXT_PUBLIC_SUPABASE_URL`
`NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

Server-only:
`OPENAI_API_KEY`
`SUPABASE_SECRET_KEY` (or the legacy `SUPABASE_SERVICE_ROLE_KEY` until migration)
`WHATSAPP_VERIFY_TOKEN`

Never put OpenAI, Supabase secret/service-role, or WhatsApp access tokens in `NEXT_PUBLIC_*` variables.
