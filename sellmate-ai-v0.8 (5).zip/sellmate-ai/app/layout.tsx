import "./globals.css";

export const metadata = {
  title: "SellMate AI",
  description: "AI sales assistant for WhatsApp businesses"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}