import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

function admin() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!
  );
}

async function generateReply(businessId: string, from: string, text: string) {
  const supabase = admin();

  const { data: business } = await supabase.from("businesses")
    .select("id,name,description,phone,currency,whatsapp_phone_number_id,whatsapp_access_token")
    .eq("id", businessId).single();

  const { data: customer } = await supabase.from("customers")
    .select("id,name,phone").eq("business_id", businessId).eq("phone", from).maybeSingle();

  const customerId = customer?.id || (await supabase.from("customers").insert({
    business_id: businessId, name: "", phone: from
  }).select("id").single()).data?.id;

  let { data: conversation } = await supabase.from("conversations")
    .select("id").eq("business_id", businessId).eq("customer_id", customerId)
    .eq("channel", "whatsapp").eq("status", "open").order("updated_at", { ascending: false }).limit(1).maybeSingle();

  if (!conversation) {
    conversation = (await supabase.from("conversations").insert({
      business_id: businessId, customer_id: customerId, channel: "whatsapp", status: "open"
    }).select("id").single()).data;
  }

  if (!conversation) throw new Error("Could not create conversation");

  await supabase.from("messages").insert({
    conversation_id: conversation.id, role: "customer", content: text
  });

  const [{ data: products }, { data: faqs }, { data: history }] = await Promise.all([
    supabase.from("products").select("name,description,price,stock,active")
      .eq("business_id", businessId).eq("active", true),
    supabase.from("faqs").select("question,answer").eq("business_id", businessId),
    supabase.from("messages").select("role,content").eq("conversation_id", conversation.id)
      .order("created_at", { ascending: false }).limit(12)
  ]);

  const productText = (products || []).map(p =>
    `- ${p.name}: ${p.price} ${business.currency}; stock ${p.stock}; ${p.description || ""}`
  ).join("\n") || "No active products.";
  const faqText = (faqs || []).map(f => `Q: ${f.question}\nA: ${f.answer}`).join("\n") || "No FAQs.";
  const recent = (history || []).reverse().map(m => `${m.role}: ${m.content}`).join("\n");

  // Lazy import keeps this route isolated from dashboard code.
  const OpenAI = (await import("openai")).default;
  const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const ai = await openai.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
    instructions: `You are ${business.name}'s WhatsApp sales assistant.
Business: ${business.description || "Not provided."}
Products:
${productText}
FAQs:
${faqText}
Recent conversation:
${recent}
Rules: use only supplied facts; never invent price, stock, delivery or policies; be concise;
if unknown, say so and offer human help; never claim an order is confirmed unless the system confirms it.`,
    input: text
  });

  const reply = ai.output_text || "Sorry, I couldn't respond right now.";

  await supabase.from("messages").insert({
    conversation_id: conversation.id, role: "assistant", content: reply
  });
  await supabase.from("conversations").update({ updated_at: new Date().toISOString() })
    .eq("id", conversation.id);

  return { reply, accessToken: business.whatsapp_access_token, phoneNumberId: business.whatsapp_phone_number_id };
}

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const mode = searchParams.get("hub.mode");
  const token = searchParams.get("hub.verify_token");
  const challenge = searchParams.get("hub.challenge");

  if (mode === "subscribe" && token && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return new NextResponse(challenge || "", { status: 200 });
  }
  return new NextResponse("Forbidden", { status: 403 });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const change = body?.entry?.[0]?.changes?.[0];
    const value = change?.value;
    const message = value?.messages?.[0];

    if (!message || message.type !== "text") return NextResponse.json({ ok: true });

    const phoneNumberId = value?.metadata?.phone_number_id;
    const from = message.from;
    const text = message.text?.body;
    if (!phoneNumberId || !from || !text) return NextResponse.json({ ok: true });

    const supabase = admin();
    const { data: business } = await supabase.from("businesses")
      .select("id").eq("whatsapp_phone_number_id", phoneNumberId).maybeSingle();

    if (!business) return NextResponse.json({ ok: true });

    const result = await generateReply(business.id, from, text);

    if (result.accessToken && result.phoneNumberId) {
      const response = await fetch(`https://graph.facebook.com/v23.0/${result.phoneNumberId}/messages`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${result.accessToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          to: from,
          type: "text",
          text: { body: result.reply }
        })
      });
      if (!response.ok) console.error("WhatsApp send failed:", await response.text());
    }

    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error(error);
    // Return 200 so providers do not endlessly retry malformed/unsupported events.
    return NextResponse.json({ ok: true });
  }
}
