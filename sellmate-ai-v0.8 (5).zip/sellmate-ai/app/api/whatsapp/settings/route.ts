import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

export async function POST(req: NextRequest) {
  const { phoneNumberId, token } = await req.json();
  const cookieStore = await cookies();
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    (process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)!,
    { cookies: { getAll: () => cookieStore.getAll(), setAll() {} } }
  );
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({error:"Unauthorized"}, {status:401});

  const { data: business } = await supabase.from("businesses").select("id")
    .eq("owner_id", user.id).maybeSingle();
  if (!business) return NextResponse.json({error:"Business not found"}, {status:400});

  // Token is stored here for MVP. For production, encrypt secrets at rest.
  const { error } = await supabase.from("businesses").update({
    whatsapp_phone_number_id: phoneNumberId,
    whatsapp_access_token: token
  }).eq("id", business.id);
  if (error) return NextResponse.json({error:error.message}, {status:400});
  return NextResponse.json({ok:true});
}
