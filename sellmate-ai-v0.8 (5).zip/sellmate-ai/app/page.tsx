import Link from "next/link";
import { ArrowRight, Bot, MessageCircle, ShoppingBag, Zap } from "lucide-react";

export default function Home() {
  return (
    <main className="landing">
      <nav className="nav">
        <div className="brand"><Bot size={22} /> SellMate AI</div>
        <Link className="button secondary" href="/dashboard">Open dashboard</Link>
      </nav>

      <section className="hero">
        <div className="pill"><Zap size={15} /> AI sales assistant for WhatsApp</div>
        <h1>Turn customer chats into sales.</h1>
        <p>
          SellMate AI helps small businesses answer customers, recommend products,
          capture leads and close more sales — 24/7.
        </p>
        <div className="hero-actions">
          <Link className="button primary" href="/dashboard">
            Start building <ArrowRight size={17} />
          </Link>
          <span className="muted">MVP preview</span>
        </div>
      </section>

      <section className="features">
        <div className="feature-card"><MessageCircle /><h3>Customer conversations</h3><p>Keep every customer interaction organized in one place.</p></div>
        <div className="feature-card"><ShoppingBag /><h3>Product knowledge</h3><p>Give the AI your products, prices, FAQs and business rules.</p></div>
        <div className="feature-card"><Bot /><h3>AI sales assistant</h3><p>Answer questions and guide customers toward an order.</p></div>
      </section>
    </main>
  );
}