 "use client";

import { useEffect, useState } from "react";

type Message = { id: string; role: string; content: string; created_at: string };
type Conversation = {
  id: string;
  status: string;
  channel: string;
  customers?: { name?: string; phone?: string };
  messages?: Message[];
};

export default function ConversationInbox() {
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [selected, setSelected] = useState<Conversation | null>(null);
  const [message, setMessage] = useState("");
  const [name, setName] = useState("Demo Customer");
  const [phone, setPhone] = useState("");
  const [sending, setSending] = useState(false);

  async function load() {
    const res = await fetch("/api/conversation/list");
    const data = await res.json();
    const items = data.conversations || [];
    setConversations(items);
    if (!selected && items[0]) setSelected(items[0]);
  }

  useEffect(() => { load(); }, []);

  async function send() {
    if (!message.trim() || sending) return;
    setSending(true);
    const res = await fetch("/api/conversation", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        customerName: name,
        customerPhone: phone,
        conversationId: selected?.id || null
      })
    });
    const data = await res.json();
    setSending(false);
    if (data.error) return alert(data.error);
    setMessage("");
    await load();
  }

  const current = conversations.find(c => c.id === selected?.id) || selected;

  return (
    <div className="inbox">
      <div className="inbox-list">
        <div className="inbox-heading"><strong>Conversations</strong><span>{conversations.length}</span></div>
        {conversations.map(c => (
          <button key={c.id} className={current?.id === c.id ? "inbox-item selected" : "inbox-item"} onClick={() => setSelected(c)}>
            <strong>{c.customers?.name || "Customer"}</strong>
            <span>{c.messages?.[c.messages.length - 1]?.content || "New conversation"}</span>
          </button>
        ))}
        {!conversations.length && <p className="empty-text">No conversations yet.</p>}
      </div>

      <div className="inbox-chat">
        <div className="chat-header">
          <div><strong>{current?.customers?.name || "New customer"}</strong><span>{current?.customers?.phone || "Web test conversation"}</span></div>
        </div>
        <div className="messages">
          {(current?.messages || []).map(m => (
            <div key={m.id} className={m.role === "assistant" ? "bubble assistant" : "bubble customer"}>{m.content}</div>
          ))}
          {!current && <div className="empty-chat">Start a test conversation below.</div>}
        </div>
        <div className="composer-meta">
          <input value={name} onChange={e => setName(e.target.value)} placeholder="Customer name"/>
          <input value={phone} onChange={e => setPhone(e.target.value)} placeholder="Phone (optional)"/>
        </div>
        <div className="composer">
          <input value={message} onChange={e => setMessage(e.target.value)} onKeyDown={e => {if(e.key==="Enter")send()}} placeholder="Type a customer message..."/>
          <button className="button primary" onClick={send} disabled={sending}>{sending ? "..." : "Send"}</button>
        </div>
      </div>
    </div>
  );
}
