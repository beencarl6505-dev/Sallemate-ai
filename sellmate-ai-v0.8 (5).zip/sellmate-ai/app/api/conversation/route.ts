import OpenAI from "openai";
import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function getSupabase() {
  const cookieStore = await cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    (process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)!,
    { cookies: { getAll: () => cookieStore.getAll(), setAll() {} } }
  );
}

export async function POST(request: NextRequest) {
  try {
    const { message, customerName = "", customerPhone = "", conversationId = null } = await request.json();
    if (!String(message || "").trim()) return NextResponse.json({ error: "Message is required." }, { status: 400 });

    const supabase = await getSupabase();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return NextResponse.json({ error: "Please log in." }, { status: 401 });

    const { data: business, error: businessError } = await supabase
      .from("businesses").select("id,name,description,phone,currency").eq("owner_id", user.id).maybeSingle();
    if (businessError) throw businessError;
    if (!business) return NextResponse.json({ error: "Business profile not found." }, { status: 400 });

    let customerId: string | null = null;

    if (customerPhone) {
      const { data: existingCustomer } = await supabase
        .from("customers").select("id")
        .eq("business_id", business.id).eq("phone", customerPhone).maybeSingle();
      customerId = existingCustomer?.id || null;
    }

    if (!customerId) {
      const { data: customer, error } = await supabase.from("customers").insert({
        business_id: business.id,
        name: String(customerName || ""),
        phone: String(customerPhone || "")
      }).select("id").single();
      if (error) throw error;
      customerId = customer.id;
    } else if (customerName) {
      await supabase.from("customers").update({ name: customerName }).eq("id", customerId);
    }

    let activeConversationId = conversationId as string | null;

    if (activeConversationId) {
      const { data: validConversation } = await supabase
        .from("conversations").select("id")
        .eq("id", activeConversationId).eq("business_id", business.id).maybeSingle();
      if (!validConversation) activeConversationId = null;
    }

    if (!activeConversationId) {
      const { data: conversation, error } = await supabase.from("conversations").insert({
        business_id: business.id,
        customer_id: customerId,
        channel: "web",
        status: "open"
      }).select("id").single();
      if (error) throw error;
      activeConversationId = conversation.id;
    }

    const { error: customerMessageError } = await supabase.from("messages").insert({
      conversation_id: activeConversationId,
      role: "customer",
      content: String(message).trim()
    });
    if (customerMessageError) throw customerMessageError;

    const [{ data: products }, { data: faqs }, { data: history }] = await Promise.all([
      supabase.from("products").select("name,description,price,stock,active").eq("business_id", business.id).eq("active", true),
      supabase.from("faqs").select("question,answer").eq("business_id", business.id),
      supabase.from("messages").select("role,content").eq("conversation_id", activeConversationId).order("created_at", { ascending: false }).limit(12)
    ]);

    const productText = (products || []).map(p => `- ${p.name}: ${p.price} ${business.currency}; stock ${p.stock}; ${p.description || ""}`).join("\n") || "No active products.";
    const faqText = (faqs || []).map(f => `Q: ${f.question}\nA: ${f.answer}`).join("\n") || "No FAQs.";
    const recentHistory = (history || []).reverse().map(m => `${m.role}: ${m.content}`).join("\n");

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions: `You are ${business.name}'s sales assistant.

Business description: ${business.description || "Not provided."}
Products:
${productText}

FAQs:
${faqText}

Conversation:
${recentHistory}

Rules:
- Use only known business information.
- Never invent products, prices, stock, delivery promises or policies.
- Be concise and natural for WhatsApp.
- If you do not know, say so and offer human help.
- If the customer wants to buy, ask for the minimum next information needed.
- Never say an order is confirmed unless the system confirms it.`,
      input: String(message).trim()
    });

    const reply = response.output_text || "I'm sorry, I couldn't respond right now.";

    const { error: assistantError } = await supabase.from("messages").insert({
      conversation_id: activeConversationId,
      role: "assistant",
      content: reply
    });
    if (assistantError) throw assistantError;

    await supabase.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", activeConversationId);

    return NextResponse.json({
      conversationId: activeConversationId,
      customerId,
      reply
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Conversation could not be processed." }, { status: 500 });
  }
}
