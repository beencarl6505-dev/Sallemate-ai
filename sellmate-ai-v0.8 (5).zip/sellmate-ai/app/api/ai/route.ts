import OpenAI from "openai";
import { NextRequest, NextResponse } from "next/server";
import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function getSupabase() {
  const cookieStore = await cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    (process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)!,
    {
      cookies: {
        getAll() { return cookieStore.getAll(); },
        setAll() {}
      }
    }
  );
}

export async function POST(request: NextRequest) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: "AI service is not configured." }, { status: 500 });
    }

    const { message } = await request.json();
    if (!message?.trim()) {
      return NextResponse.json({ error: "Message is required." }, { status: 400 });
    }

    const supabase = await getSupabase();
    const { data: { user } } = await supabase.auth.getUser();

    if (!user) {
      return NextResponse.json({ error: "Please log in first." }, { status: 401 });
    }

    const { data: business, error: businessError } = await supabase
      .from("businesses")
      .select("id,name,description,phone,currency")
      .eq("owner_id", user.id)
      .maybeSingle();

    if (businessError) throw businessError;

    if (!business) {
      return NextResponse.json(
        { error: "Create your business profile before using the AI assistant." },
        { status: 400 }
      );
    }

    const [{ data: products, error: productsError }, { data: faqs, error: faqsError }] =
      await Promise.all([
        supabase
          .from("products")
          .select("name,description,price,stock,active")
          .eq("business_id", business.id)
          .eq("active", true),
        supabase
          .from("faqs")
          .select("question,answer")
          .eq("business_id", business.id)
      ]);

    if (productsError) throw productsError;
    if (faqsError) throw faqsError;

    const productText = products?.length
      ? products.map((p) =>
          `- ${p.name}: ${p.price} ${business.currency} | stock: ${p.stock}\n  ${p.description || ""}`
        ).join("\n")
      : "No active products have been added.";

    const faqText = faqs?.length
      ? faqs.map((f) => `Q: ${f.question}\nA: ${f.answer}`).join("\n")
      : "No FAQs have been added.";

    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      instructions: `You are the sales assistant for ${business.name}.

BUSINESS:
${business.description || "No description provided."}

PHONE:
${business.phone || "Not provided."}

PRODUCTS:
${productText}

FAQS:
${faqText}

Rules:
- Use only the information above.
- Never invent products, prices, stock, discounts, delivery promises, or policies.
- If you do not know something, say so and offer human assistance.
- Keep WhatsApp replies concise and friendly.
- When a customer wants to buy, collect only the information needed to continue the order.
- Never claim an order has been placed unless the system actually confirms it.
- Never pressure or deceive the customer.`,
      input: message
    });

    return NextResponse.json({ reply: response.output_text });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "The AI assistant could not respond right now." }, { status: 500 });
  }
}
